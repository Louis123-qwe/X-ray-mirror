# X-Ray Mirror

Webcam X-ray mirror: a real 3D skull, jaw and brain follow your head; hand bones follow your hands. Video never leaves the device.

## Run
```
npm install
npm run dev        # open the printed https URL on your phone/laptop
```
Camera access needs https or localhost. Deploy on Vercel: import the repo, framework preset **Vite**, no settings needed.

## Structure
- `src/main.js` – tracking (MediaPipe Tasks Vision), head pose, Three.js scene, labels, hand overlay
- `public/models/anatomy.glb` – all anatomy in one file (skull, jaw, teeth, brain regions, eyes, eye/palate muscles, tongue, glands, neck bones)
- `public/models/labels.json` – label names with 3D anchor points
- `tools/build_models.py` – rebuilds both from the BodyParts3D .obj files (`--lists`, `--obj`, `--out`; needs python3 + numpy)
- Models are in head space (millimetres, nasion at origin, +Y up, +Z forward). Jaw parts ride on a hinge pivot.

## Tuning the fit
Fit size / Up-down / In-out sliders. Once you find values you like, change the defaults in `S` (top of `main.js`).

## Notes
- MediaPipe wasm loads from jsDelivr and the .task models from Google's storage. To self-host, download them into `public/mediapipe/` and change the URLs at the top of `main.js`.
- Anatomy: BodyParts3D, © DBCLS, CC BY-SA 2.1 Japan. Keep this credit; derived models must stay CC BY-SA.
