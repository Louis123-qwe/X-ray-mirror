import './style.css';
import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { FilesetResolver, FaceLandmarker, HandLandmarker } from '@mediapipe/tasks-vision';

const WASM = 'https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14/wasm';
const MODELS = 'https://storage.googleapis.com/mediapipe-models';
const FACE_MODEL = `${MODELS}/face_landmarker/face_landmarker/float16/1/face_landmarker.task`;
const HAND_MODEL = `${MODELS}/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task`;

const $ = (id) => document.getElementById(id);
const S = { skull: true, brain: true, teeth: true, muscles: true, eyes: true, hands: true, xray: true, bright: 0.8, size: 1, up: 0, fw: 0 };

// ---------- UI ----------
document.querySelectorAll('[data-k]').forEach((e) => (e.onchange = () => (S[e.dataset.k] = e.checked)));
const setX = (x) => { S.xray = x; $('mx').classList.toggle('on', x); $('ms').classList.toggle('on', !x); };
$('mx').onclick = () => setX(true);
$('ms').onclick = () => setX(false);
$('br').oninput = (e) => (S.bright = e.target.value / 100);
$('sz').oninput = (e) => (S.size = e.target.value / 100);
$('up').oninput = (e) => (S.up = +e.target.value);
$('fw').oninput = (e) => (S.fw = +e.target.value);
$('dm').oninput = (e) => $('stage').style.setProperty('--dim', e.target.value / 100);
$('stage').style.setProperty('--dim', 0.55);

// ---------- Three.js scene ----------
const glCanvas = $('gl');
const renderer = new THREE.WebGLRenderer({ canvas: glCanvas, alpha: true, antialias: true });
renderer.setPixelRatio(1);
renderer.setClearColor(0x000000, 0);
const scene = new THREE.Scene();
const cam = new THREE.OrthographicCamera(0, 640, 0, -480, -3000, 3000);
cam.position.z = 1000;
scene.add(new THREE.AmbientLight(0xffffff, 0.55));
const sun = new THREE.DirectionalLight(0xffffff, 0.9);
sun.position.set(-200, 300, 600);
scene.add(sun);

const glow = (rgb, base, power) =>
  new THREE.ShaderMaterial({
    transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide,
    uniforms: { k: { value: 0.8 } },
    vertexShader: 'varying vec3 vN;void main(){vN=normalize(normalMatrix*normal);gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',
    fragmentShader: `uniform float k;varying vec3 vN;void main(){float f=1.-abs(normalize(vN).z);float a=(${base}+.85*pow(f,${power}))*k;gl_FragColor=vec4(vec3(${rgb})*a,a);}`,
  });
const mat = {
  boneX: glow('.55,.82,1.', '.07', '2.'),
  brainX: glow('1.,.55,.75', '.16', '1.5'),
  muscleX: glow('1.,.35,.35', '.14', '1.6'),
  eyeX: glow('.75,.9,1.', '.2', '1.2'),
  muscleS: new THREE.MeshStandardMaterial({ color: 0xb8433f, roughness: 0.6, side: THREE.DoubleSide }),
  eyeS: new THREE.MeshStandardMaterial({ color: 0xf4f6ff, roughness: 0.3, side: THREE.DoubleSide }),
  boneS: new THREE.MeshStandardMaterial({ color: 0xe9e1cc, roughness: 0.6, side: THREE.DoubleSide }),
  brainS: new THREE.MeshStandardMaterial({ color: 0xe8a0b4, roughness: 0.7, side: THREE.DoubleSide }),
};

const root = new THREE.Group();
scene.add(root);
const parts = {};
const GROUPS = {
  bone: ['skull', 'jaw', 'teeth_upper', 'teeth_lower'],
  brain: ['brain'],
  muscle: ['muscles', 'tongue'],
  eye: ['eyes'],
};

async function loadModels() {
  const base = import.meta.env.BASE_URL + 'models/';
  const loader = new GLTFLoader();
  const files = ['skull', 'brain', 'teeth', 'muscles', 'eyes'];
  const g = Object.fromEntries(await Promise.all(files.map(async (n) => [n, (await loader.loadAsync(base + n + '.glb')).scene])));
  const take = (file, node) => {
    const o = g[file].getObjectByName(node);
    o.traverse((m) => m.isMesh && m.geometry.computeVertexNormals());
    return (parts[node] = o);
  };
  // The jaw pivots at its hinge: mandible, lower teeth and tongue ride on one pivot.
  const jaw = take('skull', 'jaw');
  const pivot = (parts.pivot = new THREE.Group());
  pivot.position.copy(jaw.position);
  jaw.position.set(0, 0, 0);
  pivot.add(jaw, take('teeth', 'teeth_lower'), take('muscles', 'tongue'));
  root.add(take('skull', 'skull'), pivot, take('teeth', 'teeth_upper'), take('muscles', 'muscles'), take('eyes', 'eyes'), take('brain', 'brain'));
}

const glows = [mat.boneX, mat.brainX, mat.muscleX, mat.eyeX];
function setMaterials() {
  glows.forEach((m) => (m.uniforms.k.value = S.bright));
  for (const [grp, names] of Object.entries(GROUPS))
    for (const n of names) parts[n].traverse((o) => o.isMesh && (o.material = mat[grp + (S.xray ? 'X' : 'S')]));
}

// ---------- Head pose from face landmarks ----------
const V3 = THREE.Vector3;
let W = 640, H = 480;
function poseHead(l) {
  const p = (i) => new V3(l[i].x * W, -l[i].y * H, -l[i].z * W);
  const a = p(234), b = p(454), nose = p(168), chin = p(152), top = p(10), m1 = p(13), m2 = p(14);
  const r = b.clone().sub(a);
  const w = r.length();
  r.normalize();
  const u0 = top.clone().sub(chin);
  const u = u0.sub(r.clone().multiplyScalar(u0.dot(r))).normalize();
  const f = new V3().crossVectors(r, u);
  const s = (w / 140) * S.size;
  root.quaternion.setFromRotationMatrix(new THREE.Matrix4().makeBasis(r, u, f));
  root.scale.setScalar(s);
  root.position.copy(nose).addScaledVector(f, -4 * s + S.fw * s).addScaledVector(u, S.up * s);
  parts.pivot.rotation.x = Math.min(0.6, Math.max(0, (m1.distanceTo(m2) / w - 0.01) * 1.4));
}

// ---------- Hand bones (2D overlay) ----------
const hctx = $('hands').getContext('2d');
const FINGERS = [[0, 1, 2, 3, 4], [0, 5, 6, 7, 8], [0, 9, 10, 11, 12], [0, 13, 14, 15, 16], [0, 17, 18, 19, 20]];
function drawHands(hands) {
  hctx.clearRect(0, 0, W, H);
  if (!S.hands) return;
  hctx.lineCap = 'round';
  hctx.shadowBlur = S.xray ? 7 : 3;
  hctx.shadowColor = S.xray ? 'rgba(110,190,255,.9)' : 'rgba(0,0,0,.5)';
  for (const h of hands) {
    const q = (i) => [h[i].x * W, h[i].y * H];
    const ps = Math.hypot(q(0)[0] - q(9)[0], q(0)[1] - q(9)[1]);
    const edge = S.xray ? `rgba(215,238,255,${0.95 * S.bright})` : '#8f8466';
    const core = S.xray ? 'rgba(20,50,90,.6)' : '#cfc5a8';
    for (const f of FINGERS) for (let i = 0; i < 4; i++) {
      const a = q(f[i]), b = q(f[i + 1]), wd = ps * (0.2 - 0.035 * i);
      for (const [col, k] of [[edge, 1], [core, 0.55]]) {
        hctx.strokeStyle = col; hctx.lineWidth = wd * k;
        hctx.beginPath(); hctx.moveTo(a[0], a[1]); hctx.lineTo(b[0], b[1]); hctx.stroke();
      }
      hctx.fillStyle = S.xray ? 'rgba(225,242,255,.8)' : '#f3ecd8';
      hctx.beginPath(); hctx.arc(b[0], b[1], wd * 0.6, 0, 7); hctx.fill();
    }
  }
}

// ---------- Tracking ----------
const ema = (prev, next, a) =>
  prev ? next.map((q, i) => ({ x: prev[i].x + (q.x - prev[i].x) * a, y: prev[i].y + (q.y - prev[i].y) * a, z: q.z })) : next;

async function makeLandmarkers() {
  const fileset = await FilesetResolver.forVisionTasks(WASM);
  const mk = async (Cls, url, extra) => {
    for (const delegate of ['GPU', 'CPU']) {
      try { return await Cls.createFromOptions(fileset, { baseOptions: { modelAssetPath: url, delegate }, runningMode: 'VIDEO', ...extra }); }
      catch (e) { console.warn(Cls.name, delegate, e); }
    }
    throw new Error('Could not load ' + Cls.name);
  };
  return [await mk(FaceLandmarker, FACE_MODEL, { numFaces: 1 }), await mk(HandLandmarker, HAND_MODEL, { numHands: 2 })];
}

$('go').onclick = async () => {
  const st = $('st'), go = $('go'), vid = $('vid');
  go.style.display = 'none';
  try {
    st.textContent = 'Starting camera…';
    vid.srcObject = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user', width: 640, height: 480 }, audio: false });
    await vid.play();
    W = vid.videoWidth; H = vid.videoHeight;
    $('stage').style.aspectRatio = `${W}/${H}`;
    $('hands').width = W; $('hands').height = H;
    renderer.setSize(W, H, false);
    Object.assign(cam, { left: 0, right: W, top: 0, bottom: -H }); cam.updateProjectionMatrix();
    st.textContent = 'Loading anatomy models…';
    await loadModels();
    st.textContent = 'Loading tracking models…';
    const [face, hand] = await makeLandmarkers();
    $('msg').style.display = 'none';

    let lm = null, hands = [], last = -1, n = 0;
    const loop = () => {
      requestAnimationFrame(loop);
      if (vid.readyState < 2 || vid.currentTime === last) return;
      last = vid.currentTime;
      const t = performance.now();
      const fr = face.detectForVideo(vid, t);
      lm = fr.faceLandmarks[0] ? ema(lm, fr.faceLandmarks[0], 0.55) : null;
      if (S.hands && n++ % 2 === 0) {
        const hr = hand.detectForVideo(vid, t);
        hands = hr.landmarks.map((h, k) => ema(hands[k], h, 0.6));
      }
      drawHands(hands);
      root.visible = !!lm;
      if (root.visible) {
        poseHead(lm);
        parts.skull.visible = parts.jaw.visible = S.skull;
        parts.teeth_upper.visible = parts.teeth_lower.visible = S.teeth;
        parts.muscles.visible = parts.tongue.visible = S.muscles;
        parts.eyes.visible = S.eyes;
        parts.brain.visible = S.brain;
        setMaterials();
      }
      renderer.render(scene, cam);
    };
    loop();
  } catch (e) {
    console.error(e);
    st.textContent = 'Could not start: ' + (e.message || e);
    go.style.display = ''; go.textContent = 'Try again';
    $('msg').style.display = '';
  }
};
