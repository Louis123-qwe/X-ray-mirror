# X-Ray Mirror

Webcam X-ray mirror: a real 3D skull, jaw and brain follow your head; hand bones follow your hands. Video never leaves the device.

## Run
```
npm install
npm run dev        # open the printed https URL on your phone/laptop
```
Camera access needs https or localhost. Deploy on Vercel: import the repo, framework preset **Vite**, no settings needed.

## Structure
- `src/main.js` – tracking (MediaPipe Tasks Vision), head pose, Three.js scene, hand overlay
- `public/models/skull.glb` – skull + `jaw` node (hinges when the mouth opens)
- `public/models/brain.glb` – brain (merged, simplified)
- `public/models/teeth.glb` – upper teeth (fixed) and lower teeth (move with the jaw)
- `public/models/muscles.glb` – eye muscles + tongue (tongue moves with the jaw)
- `public/models/eyes.glb` – both eyeballs
- Models are in head space (millimetres, nasion at origin, +Y up, +Z forward).

## Tuning the fit
Fit size / Up-down / In-out sliders. Once you find values you like, change the defaults in `S` (top of `main.js`).

## Notes
- MediaPipe wasm loads from jsDelivr and the .task models from Google's storage. To self-host, download them into `public/mediapipe/` and change the URLs at the top of `main.js`.
- Anatomy: BodyParts3D, © DBCLS, CC BY-SA 2.1 Japan. Keep this credit; derived models must stay CC BY-SA.
